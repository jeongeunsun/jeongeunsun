package com.ohgiraffers.test.uses;

public class Application {
    public static void main(String[] args) {

        BookMenu bookMenu = new BookMenu();
        bookMenu.mainMenu();

    }
}
